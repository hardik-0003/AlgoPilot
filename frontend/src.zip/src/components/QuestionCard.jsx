import { Link } from "react-router-dom";

function QuestionCard({
  question,
  completeQuestion,
  sessionType = "new",
}) {
  /*
    If the question is already solved,
    completing it means revision.

    This also protects us when the
    component is used outside Session.
  */
  const effectiveSessionType =
    question.solved
      ? "revision"
      : sessionType;

  return (
    <div className="question-card">

      <h3>
        {question.title}
      </h3>

      <p>
        <strong>Difficulty:</strong>{" "}
        {question.difficulty}
      </p>

      <p>
        <strong>Topic:</strong>{" "}
        {question.topic}
      </p>

      <p>
        <strong>Pattern:</strong>{" "}
        {question.pattern}
      </p>

      <p>
        <strong>Companies:</strong>{" "}
        {question.companies.join(", ")}
      </p>

      <p>
        <strong>Importance:</strong>{" "}
        {question.importance}
      </p>

      <p>
        <strong>Attempts:</strong>{" "}
        {question.attempts || 0}
      </p>

      {question.solved && (
        <>
          <p>
            <strong>Status:</strong>{" "}
            ✓ Solved
          </p>

          <p>
            <strong>Revision Count:</strong>{" "}
            {question.revisionCount || 0}
          </p>

          <p>
            <strong>Solved At:</strong>{" "}
            {question.solvedAt
              ? new Date(
                  question.solvedAt
                ).toLocaleDateString()
              : "Not available"}
          </p>

          <p>
            <strong>Next Revision:</strong>{" "}
            {question.nextRevision
              ? new Date(
                  question.nextRevision
                ).toLocaleDateString()
              : "Not scheduled"}
          </p>
        </>
      )}

      <div className="question-actions">

        <Link
          to={`/question/${question.id}`}
        >
          View Details →
        </Link>

        <a
          href={question.leetcodeUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Open on LeetCode →
        </a>

        <button
          onClick={() =>
            completeQuestion(
              question.id,
              effectiveSessionType
            )
          }
        >
          {effectiveSessionType ===
          "revision"
            ? "✓ Complete Revision"
            : "Mark as Solved"}
        </button>

      </div>

    </div>
  );
}

export default QuestionCard;